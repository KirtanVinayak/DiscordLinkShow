<?php

namespace plugin123\discord;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
  
  public function onEnable(): void
  {
    $this->getLogger()->notice("le plugin discor est active");
  }
  public function onDisable(): void
  {
    $this->getLogger()->("le plugin discord est desactive");
  }
  
  public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
  {
    $commandname = $command->getName();
    if($commandname == "discord"){
      if($sender instanceof Player){
        $sender->sendMessage("&b&l>> le discord est discord.gg/stnetwork");
      }
    }return true;
  }
  
}